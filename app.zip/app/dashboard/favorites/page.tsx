"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { checkAuth } from "@/lib/auth"
import DashboardLayout from "@/components/dashboard-layout"
import FileGrid from "@/components/file-grid"
import { getFavoriteFiles } from "@/lib/files"
import { Star } from "lucide-react"
import type { FileItem } from "@/lib/types"

export default function FavoritesPage() {
  const [user, setUser] = useState<any>(null)
  const [files, setFiles] = useState<FileItem[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const currentUser = checkAuth()
    if (!currentUser) {
      router.push("/")
      return
    }

    setUser(currentUser)
    loadFiles()
  }, [router])

  const loadFiles = async () => {
    try {
      const favoriteFiles = await getFavoriteFiles()
      setFiles(favoriteFiles)
    } catch (error) {
      console.error("Error loading favorite files:", error)
    } finally {
      setIsLoading(false)
    }
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400"></div>
      </div>
    )
  }

  return (
    <DashboardLayout user={user} currentPath="Dashboard > Favorit" onFileUpload={loadFiles}>
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-xl">
            <Star className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
              File Favorit
            </h1>
            <p className="text-slate-400 mt-1">File yang telah Anda tandai sebagai favorit</p>
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400"></div>
          </div>
        ) : files.length === 0 ? (
          <div className="text-center py-16">
            <div className="p-4 bg-slate-800/50 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
              <Star className="h-10 w-10 text-slate-500" />
            </div>
            <h3 className="text-xl font-semibold text-slate-300 mb-2">Belum Ada File Favorit</h3>
            <p className="text-slate-500 max-w-md mx-auto">
              Tandai file sebagai favorit dengan mengklik ikon bintang pada file untuk akses cepat
            </p>
          </div>
        ) : (
          <FileGrid files={files} onFileChange={loadFiles} />
        )}
      </div>
    </DashboardLayout>
  )
}

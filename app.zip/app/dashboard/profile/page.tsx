"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { checkAuth } from "@/lib/auth"
import DashboardLayout from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  User,
  Calendar,
  Shield,
  Settings,
  Camera,
  Edit,
  Save,
  X,
  Key,
  Bell,
  Globe,
  Smartphone,
  Monitor,
} from "lucide-react"
import { showToast } from "@/lib/toast"

export default function ProfilePage() {
  const [user, setUser] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isEditing, setIsEditing] = useState(false)
  const [editData, setEditData] = useState({
    name: "",
    email: "",
    bio: "",
    location: "",
    website: "",
  })
  const router = useRouter()

  useEffect(() => {
    const currentUser = checkAuth()
    if (!currentUser) {
      router.push("/")
      return
    }

    setUser(currentUser)
    setEditData({
      name: currentUser.name || "",
      email: currentUser.email || "",
      bio: currentUser.bio || "Pengguna CloudDrive yang antusias",
      location: currentUser.location || "Indonesia",
      website: currentUser.website || "",
    })
    setIsLoading(false)
  }, [router])

  const handleSave = async () => {
    try {
      // Simulasi update profile
      const updatedUser = { ...user, ...editData }
      localStorage.setItem("currentUser", JSON.stringify(updatedUser))
      setUser(updatedUser)
      setIsEditing(false)
      showToast("Profil berhasil diperbarui!", "success")
    } catch (error) {
      showToast("Gagal memperbarui profil", "error")
    }
  }

  const handleCancel = () => {
    setEditData({
      name: user.name || "",
      email: user.email || "",
      bio: user.bio || "Pengguna CloudDrive yang antusias",
      location: user.location || "Indonesia",
      website: user.website || "",
    })
    setIsEditing(false)
  }

  if (!user || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-sky-900 to-blue-900">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-400"></div>
      </div>
    )
  }

  const joinDate = new Date(2024, 0, 1) // Simulasi tanggal bergabung
  const formatDate = (date: Date) => {
    return date.toLocaleDateString("id-ID", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <DashboardLayout user={user} currentPath="Dashboard > Profil" onFileUpload={() => {}}>
      <div className="space-y-8">
        {/* Header Profile */}
        <div className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-sky-600/20 to-blue-600/20 rounded-3xl"></div>
          <div className="relative p-8 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-sky-500/20 rounded-full text-sky-300 text-sm font-medium mb-6">
              <User className="h-4 w-4" />
              Profil Pengguna
            </div>
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-sky-300 via-blue-300 to-sky-300 bg-clip-text text-transparent mb-4">
              Profil Saya
            </h1>
            <p className="text-slate-300 text-lg max-w-2xl mx-auto leading-relaxed">
              Kelola informasi profil dan pengaturan akun Anda
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Card */}
          <div className="lg:col-span-1">
            <Card className="bg-gradient-to-br from-slate-800/80 to-slate-900/90 border border-sky-500/30 backdrop-blur-xl">
              <CardHeader className="text-center pb-6">
                <div className="relative mx-auto mb-4">
                  <Avatar className="h-32 w-32 mx-auto ring-4 ring-sky-500/30">
                    <AvatarImage src="/placeholder-user.jpg" alt={user.name} />
                    <AvatarFallback className="bg-gradient-to-br from-sky-500 to-blue-600 text-white text-4xl font-bold">
                      {user.name.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <Button
                    size="sm"
                    className="absolute bottom-2 right-2 rounded-full bg-sky-600 hover:bg-sky-700 text-white shadow-lg"
                  >
                    <Camera className="h-4 w-4" />
                  </Button>
                </div>
                <CardTitle className="text-2xl font-bold text-white">{user.name}</CardTitle>
                <p className="text-slate-300">{user.email}</p>
                <div className="flex justify-center gap-2 mt-4">
                  <Badge className="bg-sky-500/20 text-sky-300 border-sky-400/40">
                    <Shield className="h-3 w-3 mr-1" />
                    Verified
                  </Badge>
                  <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-400/40">
                    <User className="h-3 w-3 mr-1" />
                    Premium
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3 text-slate-300">
                  <Calendar className="h-4 w-4 text-sky-400" />
                  <span className="text-sm">Bergabung {formatDate(joinDate)}</span>
                </div>
                <div className="flex items-center gap-3 text-slate-300">
                  <Globe className="h-4 w-4 text-sky-400" />
                  <span className="text-sm">{editData.location}</span>
                </div>
                {editData.website && (
                  <div className="flex items-center gap-3 text-slate-300">
                    <Monitor className="h-4 w-4 text-sky-400" />
                    <a
                      href={editData.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-sky-300 hover:text-sky-200 transition-colors"
                    >
                      {editData.website}
                    </a>
                  </div>
                )}
                <Separator className="bg-slate-700/50" />
                <p className="text-sm text-slate-300 leading-relaxed">{editData.bio}</p>
              </CardContent>
            </Card>
          </div>

          {/* Profile Information */}
          <div className="lg:col-span-2 space-y-6">
            {/* Personal Information */}
            <Card className="bg-gradient-to-br from-slate-800/80 to-slate-900/90 border border-sky-500/30 backdrop-blur-xl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white flex items-center gap-3">
                    <div className="p-2 bg-sky-500/20 rounded-lg">
                      <User className="h-5 w-5 text-sky-400" />
                    </div>
                    Informasi Personal
                  </CardTitle>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => (isEditing ? handleCancel() : setIsEditing(true))}
                    className="border-sky-500/30 text-sky-300 hover:bg-sky-500/10"
                  >
                    {isEditing ? (
                      <>
                        <X className="h-4 w-4 mr-2" />
                        Batal
                      </>
                    ) : (
                      <>
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </>
                    )}
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="text-slate-200 font-medium">
                      Nama Lengkap
                    </Label>
                    {isEditing ? (
                      <Input
                        id="name"
                        value={editData.name}
                        onChange={(e) => setEditData({ ...editData, name: e.target.value })}
                        className="bg-slate-700/50 border-slate-600 text-white focus:border-sky-500 focus:ring-sky-500/20"
                      />
                    ) : (
                      <p className="text-white font-medium">{editData.name}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-slate-200 font-medium">
                      Email
                    </Label>
                    {isEditing ? (
                      <Input
                        id="email"
                        type="email"
                        value={editData.email}
                        onChange={(e) => setEditData({ ...editData, email: e.target.value })}
                        className="bg-slate-700/50 border-slate-600 text-white focus:border-sky-500 focus:ring-sky-500/20"
                      />
                    ) : (
                      <p className="text-white font-medium">{editData.email}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location" className="text-slate-200 font-medium">
                      Lokasi
                    </Label>
                    {isEditing ? (
                      <Input
                        id="location"
                        value={editData.location}
                        onChange={(e) => setEditData({ ...editData, location: e.target.value })}
                        className="bg-slate-700/50 border-slate-600 text-white focus:border-sky-500 focus:ring-sky-500/20"
                      />
                    ) : (
                      <p className="text-white font-medium">{editData.location}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="website" className="text-slate-200 font-medium">
                      Website
                    </Label>
                    {isEditing ? (
                      <Input
                        id="website"
                        value={editData.website}
                        onChange={(e) => setEditData({ ...editData, website: e.target.value })}
                        placeholder="https://example.com"
                        className="bg-slate-700/50 border-slate-600 text-white focus:border-sky-500 focus:ring-sky-500/20"
                      />
                    ) : (
                      <p className="text-white font-medium">{editData.website || "Tidak diatur"}</p>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio" className="text-slate-200 font-medium">
                    Bio
                  </Label>
                  {isEditing ? (
                    <textarea
                      id="bio"
                      value={editData.bio}
                      onChange={(e) => setEditData({ ...editData, bio: e.target.value })}
                      rows={3}
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded-md text-white placeholder:text-slate-400 focus:border-sky-500 focus:ring-sky-500/20 resize-none"
                      placeholder="Ceritakan tentang diri Anda..."
                    />
                  ) : (
                    <p className="text-white font-medium">{editData.bio}</p>
                  )}
                </div>

                {isEditing && (
                  <div className="flex gap-3 pt-4">
                    <Button
                      onClick={handleSave}
                      className="bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-700 hover:to-blue-700 text-white"
                    >
                      <Save className="h-4 w-4 mr-2" />
                      Simpan Perubahan
                    </Button>
                    <Button variant="outline" onClick={handleCancel} className="border-slate-600 text-slate-300">
                      <X className="h-4 w-4 mr-2" />
                      Batal
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Security Settings */}
            <Card className="bg-gradient-to-br from-slate-800/80 to-slate-900/90 border border-sky-500/30 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-3">
                  <div className="p-2 bg-sky-500/20 rounded-lg">
                    <Shield className="h-5 w-5 text-sky-400" />
                  </div>
                  Keamanan & Privasi
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl border border-slate-700/30">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-sky-500/20 rounded-lg">
                      <Key className="h-5 w-5 text-sky-400" />
                    </div>
                    <div>
                      <h4 className="font-medium text-white">Password</h4>
                      <p className="text-sm text-slate-400">Terakhir diubah 30 hari lalu</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="border-sky-500/30 text-sky-300 hover:bg-sky-500/10">
                    Ubah Password
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl border border-slate-700/30">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-sky-500/20 rounded-lg">
                      <Smartphone className="h-5 w-5 text-sky-400" />
                    </div>
                    <div>
                      <h4 className="font-medium text-white">Autentikasi Dua Faktor</h4>
                      <p className="text-sm text-slate-400">Tambahan keamanan untuk akun Anda</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="border-sky-500/30 text-sky-300 hover:bg-sky-500/10">
                    Aktifkan
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl border border-slate-700/30">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-sky-500/20 rounded-lg">
                      <Bell className="h-5 w-5 text-sky-400" />
                    </div>
                    <div>
                      <h4 className="font-medium text-white">Notifikasi Email</h4>
                      <p className="text-sm text-slate-400">Terima update tentang aktivitas akun</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="border-sky-500/30 text-sky-300 hover:bg-sky-500/10">
                    Kelola
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Account Statistics */}
            <Card className="bg-gradient-to-br from-slate-800/80 to-slate-900/90 border border-sky-500/30 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-3">
                  <div className="p-2 bg-sky-500/20 rounded-lg">
                    <Settings className="h-5 w-5 text-sky-400" />
                  </div>
                  Statistik Akun
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-4 bg-slate-800/50 rounded-xl border border-slate-700/30">
                    <div className="text-2xl font-bold text-sky-400">15</div>
                    <div className="text-sm text-slate-400">Total File</div>
                  </div>
                  <div className="text-center p-4 bg-slate-800/50 rounded-xl border border-slate-700/30">
                    <div className="text-2xl font-bold text-cyan-400">2.1 GB</div>
                    <div className="text-sm text-slate-400">Storage Used</div>
                  </div>
                  <div className="text-center p-4 bg-slate-800/50 rounded-xl border border-slate-700/30">
                    <div className="text-2xl font-bold text-blue-400">5</div>
                    <div className="text-sm text-slate-400">Shared Files</div>
                  </div>
                  <div className="text-center p-4 bg-slate-800/50 rounded-xl border border-slate-700/30">
                    <div className="text-2xl font-bold text-indigo-400">30</div>
                    <div className="text-sm text-slate-400">Days Active</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}

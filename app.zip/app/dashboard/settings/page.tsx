"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { checkAuth } from "@/lib/auth"
import DashboardLayout from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Settings, Bell, Shield, Palette, Globe, Download, Trash2, Moon, Sun, Monitor } from "lucide-react"
import { showToast } from "@/lib/toast"

export default function SettingsPage() {
  const [user, setUser] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [settings, setSettings] = useState({
    notifications: {
      email: true,
      push: false,
      desktop: true,
      marketing: false,
    },
    privacy: {
      profileVisible: true,
      activityVisible: false,
      searchable: true,
    },
    appearance: {
      theme: "dark",
      language: "id",
      timezone: "Asia/Jakarta",
    },
    storage: {
      autoBackup: true,
      compressionEnabled: false,
      deleteAfterDays: 30,
    },
  })
  const router = useRouter()

  useEffect(() => {
    const currentUser = checkAuth()
    if (!currentUser) {
      router.push("/")
      return
    }

    setUser(currentUser)
    // Load settings from localStorage
    const savedSettings = localStorage.getItem("userSettings")
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings))
    }
    setIsLoading(false)
  }, [router])

  const handleSettingChange = (category: string, key: string, value: any) => {
    const newSettings = {
      ...settings,
      [category]: {
        ...settings[category as keyof typeof settings],
        [key]: value,
      },
    }
    setSettings(newSettings)
    localStorage.setItem("userSettings", JSON.stringify(newSettings))
    showToast("Pengaturan disimpan", "success")
  }

  const handleExportData = () => {
    showToast("Data sedang diekspor...", "info")
    // Simulasi export
    setTimeout(() => {
      showToast("Data berhasil diekspor!", "success")
    }, 2000)
  }

  const handleDeleteAccount = () => {
    if (confirm("Apakah Anda yakin ingin menghapus akun? Tindakan ini tidak dapat dibatalkan.")) {
      showToast("Akun akan dihapus dalam 30 hari", "warning")
    }
  }

  if (!user || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-sky-900 to-blue-900">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-400"></div>
      </div>
    )
  }

  return (
    <DashboardLayout user={user} currentPath="Dashboard > Pengaturan" onFileUpload={() => {}}>
      <div className="space-y-8">
        {/* Header */}
        <div className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-sky-600/20 to-blue-600/20 rounded-3xl"></div>
          <div className="relative p-8 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-sky-500/20 rounded-full text-sky-300 text-sm font-medium mb-6">
              <Settings className="h-4 w-4" />
              Pengaturan Sistem
            </div>
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-sky-300 via-blue-300 to-sky-300 bg-clip-text text-transparent mb-4">
              Pengaturan
            </h1>
            <p className="text-slate-300 text-lg max-w-2xl mx-auto leading-relaxed">
              Kelola preferensi dan pengaturan akun CloudDrive Anda
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Notifications */}
          <Card className="bg-gradient-to-br from-slate-800/80 to-slate-900/90 border border-sky-500/30 backdrop-blur-xl">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-3">
                <div className="p-2 bg-sky-500/20 rounded-lg">
                  <Bell className="h-5 w-5 text-sky-400" />
                </div>
                Notifikasi
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="text-slate-200 font-medium">Email Notifications</Label>
                  <p className="text-sm text-slate-400">Terima notifikasi melalui email</p>
                </div>
                <Switch
                  checked={settings.notifications.email}
                  onCheckedChange={(checked) => handleSettingChange("notifications", "email", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="text-slate-200 font-medium">Push Notifications</Label>
                  <p className="text-sm text-slate-400">Notifikasi push di browser</p>
                </div>
                <Switch
                  checked={settings.notifications.push}
                  onCheckedChange={(checked) => handleSettingChange("notifications", "push", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="text-slate-200 font-medium">Desktop Notifications</Label>
                  <p className="text-sm text-slate-400">Notifikasi desktop saat upload selesai</p>
                </div>
                <Switch
                  checked={settings.notifications.desktop}
                  onCheckedChange={(checked) => handleSettingChange("notifications", "desktop", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="text-slate-200 font-medium">Marketing Emails</Label>
                  <p className="text-sm text-slate-400">Email promosi dan update produk</p>
                </div>
                <Switch
                  checked={settings.notifications.marketing}
                  onCheckedChange={(checked) => handleSettingChange("notifications", "marketing", checked)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Privacy */}
          <Card className="bg-gradient-to-br from-slate-800/80 to-slate-900/90 border border-sky-500/30 backdrop-blur-xl">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-3">
                <div className="p-2 bg-sky-500/20 rounded-lg">
                  <Shield className="h-5 w-5 text-sky-400" />
                </div>
                Privasi
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="text-slate-200 font-medium">Profil Publik</Label>
                  <p className="text-sm text-slate-400">Izinkan orang lain melihat profil Anda</p>
                </div>
                <Switch
                  checked={settings.privacy.profileVisible}
                  onCheckedChange={(checked) => handleSettingChange("privacy", "profileVisible", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="text-slate-200 font-medium">Aktivitas Terlihat</Label>
                  <p className="text-sm text-slate-400">Tampilkan aktivitas terbaru di profil</p>
                </div>
                <Switch
                  checked={settings.privacy.activityVisible}
                  onCheckedChange={(checked) => handleSettingChange("privacy", "activityVisible", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="text-slate-200 font-medium">Dapat Dicari</Label>
                  <p className="text-sm text-slate-400">Izinkan akun ditemukan di pencarian</p>
                </div>
                <Switch
                  checked={settings.privacy.searchable}
                  onCheckedChange={(checked) => handleSettingChange("privacy", "searchable", checked)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Appearance */}
          <Card className="bg-gradient-to-br from-slate-800/80 to-slate-900/90 border border-sky-500/30 backdrop-blur-xl">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-3">
                <div className="p-2 bg-sky-500/20 rounded-lg">
                  <Palette className="h-5 w-5 text-sky-400" />
                </div>
                Tampilan
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label className="text-slate-200 font-medium">Tema</Label>
                <Select
                  value={settings.appearance.theme}
                  onValueChange={(value) => handleSettingChange("appearance", "theme", value)}
                >
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="light">
                      <div className="flex items-center gap-2">
                        <Sun className="h-4 w-4" />
                        Terang
                      </div>
                    </SelectItem>
                    <SelectItem value="dark">
                      <div className="flex items-center gap-2">
                        <Moon className="h-4 w-4" />
                        Gelap
                      </div>
                    </SelectItem>
                    <SelectItem value="system">
                      <div className="flex items-center gap-2">
                        <Monitor className="h-4 w-4" />
                        Sistem
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-slate-200 font-medium">Bahasa</Label>
                <Select
                  value={settings.appearance.language}
                  onValueChange={(value) => handleSettingChange("appearance", "language", value)}
                >
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="id">Bahasa Indonesia</SelectItem>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="es">Español</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-slate-200 font-medium">Zona Waktu</Label>
                <Select
                  value={settings.appearance.timezone}
                  onValueChange={(value) => handleSettingChange("appearance", "timezone", value)}
                >
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="Asia/Jakarta">Asia/Jakarta (WIB)</SelectItem>
                    <SelectItem value="Asia/Makassar">Asia/Makassar (WITA)</SelectItem>
                    <SelectItem value="Asia/Jayapura">Asia/Jayapura (WIT)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Storage */}
          <Card className="bg-gradient-to-br from-slate-800/80 to-slate-900/90 border border-sky-500/30 backdrop-blur-xl">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-3">
                <div className="p-2 bg-sky-500/20 rounded-lg">
                  <Globe className="h-5 w-5 text-sky-400" />
                </div>
                Penyimpanan
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="text-slate-200 font-medium">Auto Backup</Label>
                  <p className="text-sm text-slate-400">Backup otomatis file penting</p>
                </div>
                <Switch
                  checked={settings.storage.autoBackup}
                  onCheckedChange={(checked) => handleSettingChange("storage", "autoBackup", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="text-slate-200 font-medium">Kompresi File</Label>
                  <p className="text-sm text-slate-400">Kompres file untuk menghemat ruang</p>
                </div>
                <Switch
                  checked={settings.storage.compressionEnabled}
                  onCheckedChange={(checked) => handleSettingChange("storage", "compressionEnabled", checked)}
                />
              </div>

              <div className="space-y-2">
                <Label className="text-slate-200 font-medium">Hapus File Sampah Setelah</Label>
                <Select
                  value={settings.storage.deleteAfterDays.toString()}
                  onValueChange={(value) => handleSettingChange("storage", "deleteAfterDays", Number.parseInt(value))}
                >
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="7">7 Hari</SelectItem>
                    <SelectItem value="30">30 Hari</SelectItem>
                    <SelectItem value="90">90 Hari</SelectItem>
                    <SelectItem value="365">1 Tahun</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Data Management */}
        <Card className="bg-gradient-to-br from-slate-800/80 to-slate-900/90 border border-sky-500/30 backdrop-blur-xl">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-3">
              <div className="p-2 bg-sky-500/20 rounded-lg">
                <Download className="h-5 w-5 text-sky-400" />
              </div>
              Manajemen Data
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h4 className="font-medium text-white">Ekspor Data</h4>
                <p className="text-sm text-slate-400">Download semua data Anda dalam format yang dapat dibaca</p>
                <Button
                  onClick={handleExportData}
                  className="bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-700 hover:to-blue-700 text-white"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Ekspor Data
                </Button>
              </div>

              <div className="space-y-4">
                <h4 className="font-medium text-white">Hapus Akun</h4>
                <p className="text-sm text-slate-400">Hapus akun dan semua data secara permanen</p>
                <Button
                  onClick={handleDeleteAccount}
                  variant="outline"
                  className="border-red-500/30 text-red-400 hover:bg-red-500/10"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Hapus Akun
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}

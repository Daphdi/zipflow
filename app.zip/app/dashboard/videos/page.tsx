"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { checkAuth } from "@/lib/auth"
import DashboardLayout from "@/components/dashboard-layout"
import FileGrid from "@/components/file-grid"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { getFiles } from "@/lib/files"
import {
  Search,
  Filter,
  Grid,
  List,
  SortAsc,
  SortDesc,
  Video,
  Play,
  Film,
  Clock,
  Calendar,
  BarChart3,
  Clapperboard,
  Monitor,
} from "lucide-react"
import type { FileItem } from "@/lib/types"

export default function VideosPage() {
  const [user, setUser] = useState<any>(null)
  const [files, setFiles] = useState<FileItem[]>([])
  const [filteredFiles, setFilteredFiles] = useState<FileItem[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [sortBy, setSortBy] = useState("date")
  const [sortOrder, setSortOrder] = useState("desc")
  const [filterType, setFilterType] = useState("all")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const router = useRouter()

  useEffect(() => {
    const currentUser = checkAuth()
    if (!currentUser) {
      router.push("/")
      return
    }

    setUser(currentUser)
    loadFiles()
  }, [router])

  useEffect(() => {
    filterAndSortFiles()
  }, [files, searchQuery, sortBy, sortOrder, filterType])

  const loadFiles = async () => {
    try {
      const userFiles = await getFiles()
      // Filter hanya video dengan kategori yang lebih spesifik
      const videos = userFiles.filter((file) => file.type.startsWith("video/"))
      setFiles(videos)
    } catch (error) {
      console.error("Error loading files:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const filterAndSortFiles = () => {
    let filtered = [...files]

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter((file) => file.name.toLowerCase().includes(searchQuery.toLowerCase()))
    }

    // Filter by video type
    if (filterType !== "all") {
      filtered = filtered.filter((file) => {
        switch (filterType) {
          case "mp4":
            return file.type.includes("mp4")
          case "avi":
            return file.type.includes("avi")
          case "mov":
            return file.type.includes("mov") || file.type.includes("quicktime")
          case "mkv":
            return file.type.includes("mkv") || file.type.includes("matroska")
          case "webm":
            return file.type.includes("webm")
          case "large":
            return file.size > 100 * 1024 * 1024 // > 100MB
          case "small":
            return file.size < 10 * 1024 * 1024 // < 10MB
          case "hd":
            return (
              file.name.toLowerCase().includes("hd") ||
              file.name.toLowerCase().includes("1080") ||
              file.name.toLowerCase().includes("720")
            )
          default:
            return true
        }
      })
    }

    // Sort files
    filtered.sort((a, b) => {
      let comparison = 0
      switch (sortBy) {
        case "name":
          comparison = a.name.localeCompare(b.name)
          break
        case "size":
          comparison = a.size - b.size
          break
        case "date":
          comparison = new Date(a.uploadedAt).getTime() - new Date(b.uploadedAt).getTime()
          break
        default:
          comparison = 0
      }
      return sortOrder === "asc" ? comparison : -comparison
    })

    setFilteredFiles(filtered)
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i]
  }

  const formatDuration = (filename: string) => {
    // Simulasi durasi berdasarkan ukuran file (untuk demo)
    // Dalam implementasi nyata, ini akan menggunakan metadata video
    const randomMinutes = Math.floor(Math.random() * 60) + 1
    const randomSeconds = Math.floor(Math.random() * 60)
    return `${randomMinutes}:${randomSeconds.toString().padStart(2, "0")}`
  }

  const getVideoStats = () => {
    const stats = {
      mp4: files.filter((f) => f.type.includes("mp4")).length,
      avi: files.filter((f) => f.type.includes("avi")).length,
      mov: files.filter((f) => f.type.includes("mov") || f.type.includes("quicktime")).length,
      mkv: files.filter((f) => f.type.includes("mkv") || f.type.includes("matroska")).length,
      webm: files.filter((f) => f.type.includes("webm")).length,
      other: files.filter(
        (f) =>
          !f.type.includes("mp4") &&
          !f.type.includes("avi") &&
          !f.type.includes("mov") &&
          !f.type.includes("quicktime") &&
          !f.type.includes("mkv") &&
          !f.type.includes("matroska") &&
          !f.type.includes("webm"),
      ).length,
    }
    return stats
  }

  const getTotalSize = () => {
    return files.reduce((total, file) => total + file.size, 0)
  }

  const getTotalDuration = () => {
    // Simulasi total durasi (dalam implementasi nyata akan menggunakan metadata)
    const totalMinutes = files.length * 5 // Asumsi rata-rata 5 menit per video
    const hours = Math.floor(totalMinutes / 60)
    const minutes = totalMinutes % 60
    return `${hours}h ${minutes}m`
  }

  const getRecentVideos = () => {
    return files.sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()).slice(0, 4)
  }

  const getLargestVideos = () => {
    return files.sort((a, b) => b.size - a.size).slice(0, 3)
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400"></div>
      </div>
    )
  }

  const videoStats = getVideoStats()
  const totalSize = getTotalSize()
  const totalDuration = getTotalDuration()
  const recentVideos = getRecentVideos()
  const largestVideos = getLargestVideos()

  return (
    <DashboardLayout user={user} currentPath="Dashboard > Videos" onFileUpload={loadFiles}>
      <div className="space-y-8">
        {/* Enhanced Header with Cinematic Appeal */}
        <div className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-red-600/20 via-orange-600/20 to-yellow-600/20 rounded-3xl"></div>
          <div className="relative p-8 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-red-500/20 rounded-full text-red-300 text-sm font-medium mb-6">
              <Clapperboard className="h-4 w-4" />
              Video Studio
            </div>
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-red-400 via-orange-400 to-yellow-400 bg-clip-text text-transparent mb-4">
              Koleksi Video
            </h1>
            <p className="text-slate-400 text-lg max-w-2xl mx-auto leading-relaxed">
              Studio video pribadi Anda. Kelola, putar, dan organize semua video dengan mudah.
            </p>
            <div className="flex flex-wrap justify-center gap-6 mt-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-white">{files.length}</div>
                <div className="text-sm text-slate-400">Total Video</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-400">{formatFileSize(totalSize)}</div>
                <div className="text-sm text-slate-400">Total Ukuran</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-400">{totalDuration}</div>
                <div className="text-sm text-slate-400">Estimasi Durasi</div>
              </div>
            </div>
          </div>
        </div>

        {/* Video Format Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {videoStats.mp4 > 0 && (
            <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/5 border-blue-400/20 hover:border-blue-400/40 transition-all duration-300">
              <CardContent className="p-4 text-center">
                <div className="p-3 bg-blue-500/20 rounded-xl w-fit mx-auto mb-3">
                  <Video className="h-6 w-6 text-blue-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1">{videoStats.mp4}</div>
                <div className="text-sm text-slate-400">MP4</div>
              </CardContent>
            </Card>
          )}

          {videoStats.avi > 0 && (
            <Card className="bg-gradient-to-br from-green-500/10 to-green-600/5 border-green-400/20 hover:border-green-400/40 transition-all duration-300">
              <CardContent className="p-4 text-center">
                <div className="p-3 bg-green-500/20 rounded-xl w-fit mx-auto mb-3">
                  <Film className="h-6 w-6 text-green-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1">{videoStats.avi}</div>
                <div className="text-sm text-slate-400">AVI</div>
              </CardContent>
            </Card>
          )}

          {videoStats.mov > 0 && (
            <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/5 border-purple-400/20 hover:border-purple-400/40 transition-all duration-300">
              <CardContent className="p-4 text-center">
                <div className="p-3 bg-purple-500/20 rounded-xl w-fit mx-auto mb-3">
                  <Monitor className="h-6 w-6 text-purple-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1">{videoStats.mov}</div>
                <div className="text-sm text-slate-400">MOV</div>
              </CardContent>
            </Card>
          )}

          {videoStats.mkv > 0 && (
            <Card className="bg-gradient-to-br from-red-500/10 to-red-600/5 border-red-400/20 hover:border-red-400/40 transition-all duration-300">
              <CardContent className="p-4 text-center">
                <div className="p-3 bg-red-500/20 rounded-xl w-fit mx-auto mb-3">
                  <Video className="h-6 w-6 text-red-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1">{videoStats.mkv}</div>
                <div className="text-sm text-slate-400">MKV</div>
              </CardContent>
            </Card>
          )}

          {videoStats.webm > 0 && (
            <Card className="bg-gradient-to-br from-yellow-500/10 to-yellow-600/5 border-yellow-400/20 hover:border-yellow-400/40 transition-all duration-300">
              <CardContent className="p-4 text-center">
                <div className="p-3 bg-yellow-500/20 rounded-xl w-fit mx-auto mb-3">
                  <Play className="h-6 w-6 text-yellow-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1">{videoStats.webm}</div>
                <div className="text-sm text-slate-400">WebM</div>
              </CardContent>
            </Card>
          )}

          {videoStats.other > 0 && (
            <Card className="bg-gradient-to-br from-gray-500/10 to-gray-600/5 border-gray-400/20 hover:border-gray-400/40 transition-all duration-300">
              <CardContent className="p-4 text-center">
                <div className="p-3 bg-gray-500/20 rounded-xl w-fit mx-auto mb-3">
                  <Video className="h-6 w-6 text-gray-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1">{videoStats.other}</div>
                <div className="text-sm text-slate-400">Lainnya</div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Recent Videos Preview */}
        {recentVideos.length > 0 && (
          <Card className="bg-gradient-to-br from-slate-800/80 to-slate-900/90 border-slate-600/50">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-3">
                <div className="p-2 bg-red-500/20 rounded-lg">
                  <Calendar className="h-5 w-5 text-red-400" />
                </div>
                Video Terbaru
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {recentVideos.map((video) => (
                  <div
                    key={video.id}
                    className="group relative aspect-video bg-slate-800/50 rounded-xl overflow-hidden border border-slate-700/30 hover:border-red-400/30 transition-all duration-300"
                  >
                    <div className="w-full h-full bg-gradient-to-br from-slate-700 to-slate-800 flex items-center justify-center">
                      <div className="p-4 bg-red-500/20 rounded-full group-hover:bg-red-500/30 transition-colors duration-300">
                        <Play className="h-8 w-8 text-red-400" />
                      </div>
                    </div>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <div className="absolute bottom-3 left-3 right-3">
                        <p className="text-white text-sm font-medium truncate">{video.name}</p>
                        <div className="flex items-center justify-between mt-1">
                          <p className="text-slate-300 text-xs">{formatFileSize(video.size)}</p>
                          <div className="flex items-center gap-1 text-xs text-slate-300">
                            <Clock className="h-3 w-3" />
                            {formatDuration(video.name)}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Largest Videos Info */}
        {largestVideos.length > 0 && (
          <Card className="bg-gradient-to-br from-slate-800/80 to-slate-900/90 border-slate-600/50">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-3">
                <div className="p-2 bg-orange-500/20 rounded-lg">
                  <BarChart3 className="h-5 w-5 text-orange-400" />
                </div>
                Video Terbesar
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {largestVideos.map((video, index) => (
                  <div
                    key={video.id}
                    className="flex items-center gap-4 p-4 bg-slate-800/50 rounded-xl border border-slate-700/30"
                  >
                    <div className="flex items-center justify-center w-8 h-8 bg-orange-500/20 rounded-lg text-orange-400 font-bold text-sm">
                      {index + 1}
                    </div>
                    <div className="w-16 h-12 bg-slate-700/30 rounded-lg overflow-hidden flex items-center justify-center">
                      <Play className="h-6 w-6 text-slate-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold text-white truncate">{video.name}</h4>
                      <div className="flex items-center gap-3 text-sm text-slate-400">
                        <span>{formatFileSize(video.size)}</span>
                        <span>•</span>
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {formatDuration(video.name)}
                        </div>
                      </div>
                    </div>
                    <Badge className="bg-orange-500/20 text-orange-300 border-orange-400/40">
                      {formatFileSize(video.size)}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Enhanced Filters and Search */}
        <div className="flex flex-col lg:flex-row gap-4 p-6 bg-slate-800/30 rounded-2xl border border-slate-700/30 backdrop-blur-sm">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
            <Input
              placeholder="Cari video..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-red-500 focus:ring-red-500/20"
            />
          </div>

          <div className="flex flex-wrap gap-3">
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-48 bg-slate-700/50 border-slate-600 text-white">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                <SelectItem value="all">Semua Video</SelectItem>
                <SelectItem value="mp4">MP4</SelectItem>
                <SelectItem value="avi">AVI</SelectItem>
                <SelectItem value="mov">MOV/QuickTime</SelectItem>
                <SelectItem value="mkv">MKV</SelectItem>
                <SelectItem value="webm">WebM</SelectItem>
                <SelectItem value="large">Video Besar (&gt;100MB)</SelectItem>
                <SelectItem value="small">Video Kecil (&lt;10MB)</SelectItem>
                <SelectItem value="hd">HD Quality</SelectItem>
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-32 bg-slate-700/50 border-slate-600 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                <SelectItem value="date">Tanggal</SelectItem>
                <SelectItem value="name">Nama</SelectItem>
                <SelectItem value="size">Ukuran</SelectItem>
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              size="sm"
              onClick={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")}
              className="border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              {sortOrder === "asc" ? <SortAsc className="h-4 w-4" /> : <SortDesc className="h-4 w-4" />}
            </Button>

            <div className="flex border border-slate-600 rounded-lg overflow-hidden">
              <Button
                variant={viewMode === "grid" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("grid")}
                className={`rounded-none ${
                  viewMode === "grid" ? "bg-red-600 text-white" : "text-slate-300 hover:bg-slate-700"
                }`}
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === "list" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("list")}
                className={`rounded-none ${
                  viewMode === "list" ? "bg-red-600 text-white" : "text-slate-300 hover:bg-slate-700"
                }`}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Videos Display */}
        {isLoading ? (
          <div className="flex items-center justify-center py-16">
            <div className="relative">
              <div className="animate-spin rounded-full h-12 w-12 border-4 border-red-500/20 border-t-red-500"></div>
              <div className="absolute inset-0 animate-ping rounded-full h-12 w-12 border-4 border-red-500/10"></div>
            </div>
          </div>
        ) : filteredFiles.length === 0 ? (
          <div className="text-center py-16">
            <div className="p-6 bg-slate-800/50 rounded-3xl w-24 h-24 mx-auto mb-6 flex items-center justify-center">
              <Video className="h-12 w-12 text-slate-500" />
            </div>
            <h3 className="text-xl font-semibold text-slate-300 mb-2">
              {searchQuery || filterType !== "all" ? "Tidak Ada Video Ditemukan" : "Belum Ada Video"}
            </h3>
            <p className="text-slate-500 max-w-md mx-auto">
              {searchQuery || filterType !== "all"
                ? "Coba ubah filter atau kata kunci pencarian"
                : "Upload video pertama Anda untuk memulai koleksi"}
            </p>
          </div>
        ) : (
          <FileGrid files={filteredFiles} onFileChange={loadFiles} viewMode={viewMode} />
        )}
      </div>
    </DashboardLayout>
  )
}

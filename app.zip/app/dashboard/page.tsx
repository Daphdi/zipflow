"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { checkAuth } from "@/lib/auth"
import DashboardLayout from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getFiles, getStorageStats } from "@/lib/files"
import { Files, Upload, Star, Clock, ArrowRight, Cloud, HardDrive, TrendingUp } from "lucide-react"
import Link from "next/link"
import type { FileItem, StorageStats } from "@/lib/types"

export default function DashboardPage() {
  const [user, setUser] = useState<any>(null)
  const [files, setFiles] = useState<FileItem[]>([])
  const [storageStats, setStorageStats] = useState<StorageStats | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const currentUser = checkAuth()
    if (!currentUser) {
      router.push("/")
      return
    }

    setUser(currentUser)
    loadFiles()
  }, [router])

  const loadFiles = async () => {
    try {
      const userFiles = await getFiles()
      const stats = await getStorageStats()
      setFiles(userFiles)
      setStorageStats(stats)
    } catch (error) {
      console.error("Error loading files:", error)
    } finally {
      setIsLoading(false)
    }
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-sky-900 to-blue-900">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-400"></div>
      </div>
    )
  }

  const recentFiles = files
    .sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime())
    .slice(0, 6)

  const todayUploads = files.filter((f) => new Date(f.uploadedAt).toDateString() === new Date().toDateString()).length

  const favoriteFiles = files.filter((f) => f.isFavorite).length

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i]
  }

  // Tambahkan fungsi ini setelah formatFileSize
  const getFileRoute = (type: string) => {
    if (type.startsWith("image/")) return "/dashboard/images"
    if (type.startsWith("video/")) return "/dashboard/videos"
    if (type.includes("pdf") || type.includes("doc") || type.includes("txt")) return "/dashboard/documents"
    return "/dashboard/files"
  }

  const getFileIcon = (type: string) => {
    if (type.startsWith("image/")) return "🖼️"
    if (type.startsWith("video/")) return "🎥"
    if (type.startsWith("audio/")) return "🎵"
    if (type.includes("pdf")) return "📄"
    if (type.includes("doc")) return "📝"
    return "📁"
  }

  return (
    <DashboardLayout user={user} currentPath="Dashboard" onFileUpload={loadFiles}>
      <div className="space-y-8">
        {/* Hero Welcome Section */}
        <div className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-sky-600/20 to-blue-600/20 rounded-3xl"></div>
          <div className="relative p-8 md:p-12 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-sky-500/20 rounded-full text-sky-300 text-sm font-medium mb-6">
              <Cloud className="h-4 w-4" />
              Selamat datang kembali!
            </div>
            <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-sky-300 via-blue-300 to-sky-300 bg-clip-text text-transparent mb-4">
              Halo, {user.name}! 👋
            </h1>
            <p className="text-slate-300 text-lg md:text-xl max-w-3xl mx-auto leading-relaxed">
              Kelola semua file Anda dengan mudah dan elegan. Upload, organize, dan akses file dari mana saja dengan
              kecepatan tinggi.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
              <Link href="/dashboard/files">
                <Button className="bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-700 hover:to-blue-700 text-white px-8 py-3 rounded-xl font-semibold shadow-lg shadow-sky-500/25 transition-all duration-300 hover:scale-105 glow-sky">
                  Lihat Semua File
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link href="/dashboard/storage">
                <Button
                  variant="outline"
                  className="border-sky-500/30 text-sky-300 hover:bg-sky-500/10 px-8 py-3 rounded-xl font-semibold transition-all duration-300 hover:scale-105"
                >
                  Kelola Storage
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Enhanced Stats Cards with Sky Blue Theme */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Total Files Card */}
          <Card className="group relative overflow-hidden bg-gradient-to-br from-slate-800/90 to-slate-900/90 border border-sky-400/30 backdrop-blur-sm hover:shadow-2xl hover:shadow-sky-500/25 transition-all duration-500 hover:scale-[1.02] hover:-translate-y-1">
            <div className="absolute inset-0 bg-gradient-to-br from-sky-500/10 to-blue-600/5 group-hover:from-sky-500/15 group-hover:to-blue-600/10 transition-all duration-500"></div>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3 relative z-10">
              <CardTitle className="text-sm font-semibold text-slate-200">Total File</CardTitle>
              <div className="p-3 bg-sky-500/20 rounded-xl group-hover:bg-sky-500/30 transition-all duration-300 shadow-lg border border-sky-400/20">
                <Files className="h-5 w-5 text-sky-300" />
              </div>
            </CardHeader>
            <CardContent className="relative z-10">
              <div className="text-4xl font-bold text-white mb-2 group-hover:text-sky-100 transition-colors">
                {files.length}
              </div>
              <p className="text-sm text-slate-300 flex items-center gap-2 font-medium">
                <TrendingUp className="h-3 w-3 text-sky-400" />
                File tersimpan
              </p>
            </CardContent>
          </Card>

          {/* Upload Today Card */}
          <Card className="group relative overflow-hidden bg-gradient-to-br from-slate-800/90 to-slate-900/90 border border-cyan-400/30 backdrop-blur-sm hover:shadow-2xl hover:shadow-cyan-500/25 transition-all duration-500 hover:scale-[1.02] hover:-translate-y-1">
            <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/10 to-sky-600/5 group-hover:from-cyan-500/15 group-hover:to-sky-600/10 transition-all duration-500"></div>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3 relative z-10">
              <CardTitle className="text-sm font-semibold text-slate-200">Upload Hari Ini</CardTitle>
              <div className="p-3 bg-cyan-500/20 rounded-xl group-hover:bg-cyan-500/30 transition-all duration-300 shadow-lg border border-cyan-400/20">
                <Upload className="h-5 w-5 text-cyan-300" />
              </div>
            </CardHeader>
            <CardContent className="relative z-10">
              <div className="text-4xl font-bold text-white mb-2 group-hover:text-cyan-100 transition-colors">
                {todayUploads}
              </div>
              <p className="text-sm text-slate-300 flex items-center gap-2 font-medium">
                <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
                File baru hari ini
              </p>
            </CardContent>
          </Card>

          {/* Favorite Files Card */}
          <Card className="group relative overflow-hidden bg-gradient-to-br from-slate-800/90 to-slate-900/90 border border-amber-400/30 backdrop-blur-sm hover:shadow-2xl hover:shadow-amber-500/25 transition-all duration-500 hover:scale-[1.02] hover:-translate-y-1">
            <div className="absolute inset-0 bg-gradient-to-br from-amber-500/10 to-yellow-600/5 group-hover:from-amber-500/15 group-hover:to-yellow-600/10 transition-all duration-500"></div>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3 relative z-10">
              <CardTitle className="text-sm font-semibold text-slate-200">File Favorit</CardTitle>
              <div className="p-3 bg-amber-500/20 rounded-xl group-hover:bg-amber-500/30 transition-all duration-300 shadow-lg border border-amber-400/20">
                <Star className="h-5 w-5 text-amber-300 fill-current" />
              </div>
            </CardHeader>
            <CardContent className="relative z-10">
              <div className="text-4xl font-bold text-white mb-2 group-hover:text-amber-100 transition-colors">
                {favoriteFiles}
              </div>
              <p className="text-sm text-slate-300 flex items-center gap-2 font-medium">
                <Star className="h-3 w-3 text-amber-400 fill-current" />
                Ditandai favorit
              </p>
            </CardContent>
          </Card>

          {/* Storage Used Card */}
          <Card className="group relative overflow-hidden bg-gradient-to-br from-slate-800/90 to-slate-900/90 border border-blue-400/30 backdrop-blur-sm hover:shadow-2xl hover:shadow-blue-500/25 transition-all duration-500 hover:scale-[1.02] hover:-translate-y-1">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-indigo-600/5 group-hover:from-blue-500/15 group-hover:to-indigo-600/10 transition-all duration-500"></div>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3 relative z-10">
              <CardTitle className="text-sm font-semibold text-slate-200">Storage Terpakai</CardTitle>
              <div className="p-3 bg-blue-500/20 rounded-xl group-hover:bg-blue-500/30 transition-all duration-300 shadow-lg border border-blue-400/20">
                <HardDrive className="h-5 w-5 text-blue-300" />
              </div>
            </CardHeader>
            <CardContent className="relative z-10">
              <div className="text-4xl font-bold text-white mb-2 group-hover:text-blue-100 transition-colors">
                {storageStats ? formatFileSize(storageStats.used) : "0 B"}
              </div>
              <p className="text-sm text-slate-300 flex items-center gap-2 font-medium">
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                dari {storageStats ? formatFileSize(storageStats.total) : "15 GB"}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Enhanced Recent Files Preview */}
        <Card className="group relative overflow-hidden bg-gradient-to-br from-slate-800/80 to-slate-900/90 border border-slate-600/50 backdrop-blur-xl shadow-2xl">
          <div className="absolute inset-0 bg-gradient-to-br from-sky-500/5 via-transparent to-blue-500/5 group-hover:from-sky-500/8 group-hover:to-blue-500/8 transition-all duration-700"></div>
          <CardHeader className="pb-6 relative z-10">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <div className="p-3 bg-slate-700/80 rounded-2xl shadow-lg border border-slate-600/50">
                    <Clock className="h-6 w-6 text-slate-200" />
                  </div>
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-gradient-to-r from-sky-500 to-blue-500 rounded-full animate-pulse"></div>
                </div>
                <div>
                  <CardTitle className="text-2xl font-bold text-white">File Terbaru</CardTitle>
                  <p className="text-slate-300 text-sm mt-1 font-medium">File yang baru saja Anda upload</p>
                </div>
              </div>
              <Link href="/dashboard/files">
                <Button className="bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-700 hover:to-blue-700 text-white border-0 shadow-lg shadow-sky-500/25 hover:shadow-sky-500/40 transition-all duration-300 hover:scale-105 glow-sky">
                  Lihat Semua
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent className="relative z-10">
            {isLoading ? (
              <div className="flex items-center justify-center py-16">
                <div className="relative">
                  <div className="animate-spin rounded-full h-12 w-12 border-4 border-sky-500/20 border-t-sky-500"></div>
                  <div className="absolute inset-0 animate-ping rounded-full h-12 w-12 border-4 border-sky-500/10"></div>
                </div>
              </div>
            ) : recentFiles.length === 0 ? (
              <div className="text-center py-16">
                <div className="relative mb-6">
                  <div className="p-6 bg-slate-700/60 rounded-3xl w-24 h-24 mx-auto flex items-center justify-center shadow-xl border border-slate-600/50">
                    <Upload className="h-12 w-12 text-slate-300" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-6 h-6 bg-gradient-to-r from-sky-500 to-blue-500 rounded-full animate-bounce"></div>
                </div>
                <h3 className="text-xl font-bold text-white mb-3">Belum Ada File</h3>
                <p className="text-slate-300 mb-6 max-w-sm mx-auto">
                  Upload file pertama Anda untuk memulai perjalanan digital
                </p>
                <Button className="bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-700 hover:to-blue-700 text-white shadow-lg shadow-sky-500/25 hover:shadow-sky-500/40 transition-all duration-300 hover:scale-105 glow-sky">
                  <Upload className="mr-2 h-4 w-4" />
                  Upload File
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {recentFiles.map((file, index) => (
                  <Link
                    key={file.id}
                    href={getFileRoute(file.type)}
                    className="block group relative p-5 bg-slate-800/60 rounded-2xl border border-slate-600/40 hover:border-sky-400/50 hover:bg-slate-800/80 transition-all duration-500 hover:shadow-xl hover:shadow-sky-500/15 hover:scale-[1.02] hover:-translate-y-1 cursor-pointer"
                    style={{ animationDelay: `${index * 100}ms` }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-sky-500/5 to-blue-500/5 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                    <div className="relative z-10 flex items-start gap-4">
                      <div className="text-3xl group-hover:scale-110 transition-transform duration-300">
                        {getFileIcon(file.type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-white truncate group-hover:text-sky-200 transition-colors duration-300 text-base">
                          {file.name}
                        </h4>
                        <div className="flex items-center gap-3 mt-2 text-sm text-slate-300">
                          <span className="font-medium">{formatFileSize(file.size)}</span>
                          <div className="w-1 h-1 bg-slate-400 rounded-full"></div>
                          <span>{new Date(file.uploadedAt).toLocaleDateString("id-ID")}</span>
                        </div>
                        {file.isFavorite && (
                          <div className="flex items-center gap-2 mt-3">
                            <div className="p-1 bg-amber-500/30 rounded-lg border border-amber-400/30">
                              <Star className="h-3 w-3 text-amber-300 fill-current" />
                            </div>
                            <span className="text-xs text-amber-300 font-medium">Favorit</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}

"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { checkAuth } from "@/lib/auth"
import DashboardLayout from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { getFiles, getStorageStats } from "@/lib/files"
import { HardDrive, FileText, ImageIcon, Video, Music, Archive } from "lucide-react"
import type { FileItem, StorageStats } from "@/lib/types"

export default function StoragePage() {
  const [user, setUser] = useState<any>(null)
  const [files, setFiles] = useState<FileItem[]>([])
  const [storageStats, setStorageStats] = useState<StorageStats | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const currentUser = checkAuth()
    if (!currentUser) {
      router.push("/")
      return
    }

    setUser(currentUser)
    loadStorageData()
  }, [router])

  const loadStorageData = async () => {
    try {
      const userFiles = await getFiles()
      const stats = await getStorageStats()
      setFiles(userFiles)
      setStorageStats(stats)
    } catch (error) {
      console.error("Error loading storage data:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB", "TB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  if (!user || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400"></div>
      </div>
    )
  }

  const usagePercentage = storageStats ? (storageStats.used / storageStats.total) * 100 : 0

  return (
    <DashboardLayout user={user} currentPath="Dashboard > Penyimpanan" onFileUpload={loadStorageData}>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            Penyimpanan
          </h1>
          <p className="text-slate-400 mt-2">Kelola dan pantau penggunaan penyimpanan Anda</p>
        </div>

        {/* Storage Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700 col-span-full lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <HardDrive className="h-5 w-5 text-purple-400" />
                Penggunaan Penyimpanan
              </CardTitle>
              <CardDescription className="text-slate-400">
                {storageStats ? formatBytes(storageStats.used) : "0 Bytes"} dari{" "}
                {storageStats ? formatBytes(storageStats.total) : "15 GB"} digunakan
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-300">Terpakai</span>
                  <span className="text-slate-300">{usagePercentage.toFixed(1)}%</span>
                </div>
                <Progress value={usagePercentage} className="h-3 bg-slate-700">
                  <div
                    className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all"
                    style={{ width: `${usagePercentage}%` }}
                  />
                </Progress>
              </div>
              <div className="grid grid-cols-2 gap-4 pt-4">
                <div className="text-center p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                  <div className="text-2xl font-bold text-purple-400">
                    {storageStats ? formatBytes(storageStats.used) : "0 Bytes"}
                  </div>
                  <div className="text-sm text-slate-400">Terpakai</div>
                </div>
                <div className="text-center p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                  <div className="text-2xl font-bold text-green-400">
                    {storageStats ? formatBytes(storageStats.total - storageStats.used) : "15 GB"}
                  </div>
                  <div className="text-sm text-slate-400">Tersisa</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Total File</CardTitle>
              <CardDescription className="text-slate-400">Jumlah file yang tersimpan</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-400">{files.length}</div>
              <p className="text-sm text-slate-400 mt-2">File tersimpan</p>
            </CardContent>
          </Card>
        </div>

        {/* File Type Breakdown */}
        <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Breakdown Jenis File</CardTitle>
            <CardDescription className="text-slate-400">Distribusi file berdasarkan jenis</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {storageStats?.fileTypes.map((fileType) => {
                const getIcon = (type: string) => {
                  switch (type) {
                    case "images":
                      return <ImageIcon className="h-5 w-5 text-blue-400" />
                    case "videos":
                      return <Video className="h-5 w-5 text-red-400" />
                    case "documents":
                      return <FileText className="h-5 w-5 text-green-400" />
                    case "audio":
                      return <Music className="h-5 w-5 text-yellow-400" />
                    default:
                      return <Archive className="h-5 w-5 text-gray-400" />
                  }
                }

                const getTypeLabel = (type: string) => {
                  switch (type) {
                    case "images":
                      return "Gambar"
                    case "videos":
                      return "Video"
                    case "documents":
                      return "Dokumen"
                    case "audio":
                      return "Audio"
                    default:
                      return "Lainnya"
                  }
                }

                return (
                  <div key={fileType.type} className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                    <div className="flex items-center gap-3 mb-2">
                      {getIcon(fileType.type)}
                      <span className="text-white font-medium">{getTypeLabel(fileType.type)}</span>
                    </div>
                    <div className="space-y-1">
                      <div className="text-lg font-bold text-slate-200">{formatBytes(fileType.size)}</div>
                      <div className="text-sm text-slate-400">{fileType.count} file</div>
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Aktivitas Terbaru</CardTitle>
            <CardDescription className="text-slate-400">File yang baru saja diupload</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {files
                .sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime())
                .slice(0, 5)
                .map((file) => (
                  <div key={file.id} className="flex items-center gap-3 p-3 bg-slate-800/30 rounded-lg">
                    <div className="p-2 bg-purple-500/20 rounded-lg">
                      <FileText className="h-4 w-4 text-purple-400" />
                    </div>
                    <div className="flex-1">
                      <div className="text-white font-medium truncate">{file.name}</div>
                      <div className="text-sm text-slate-400">
                        {formatBytes(file.size)} • {new Date(file.uploadedAt).toLocaleDateString("id-ID")}
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}

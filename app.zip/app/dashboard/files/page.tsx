"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { checkAuth } from "@/lib/auth"
import DashboardLayout from "@/components/dashboard-layout"
import FileGrid from "@/components/file-grid"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getFiles } from "@/lib/files"
import { Search, Filter, Grid, List, SortAsc, SortDesc } from "lucide-react"
import type { FileItem } from "@/lib/types"

export default function FilesPage() {
  const [user, setUser] = useState<any>(null)
  const [files, setFiles] = useState<FileItem[]>([])
  const [filteredFiles, setFilteredFiles] = useState<FileItem[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [sortBy, setSortBy] = useState("date")
  const [sortOrder, setSortOrder] = useState("desc")
  const [filterType, setFilterType] = useState("all")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const router = useRouter()

  useEffect(() => {
    const currentUser = checkAuth()
    if (!currentUser) {
      router.push("/")
      return
    }

    setUser(currentUser)
    loadFiles()
  }, [router])

  useEffect(() => {
    filterAndSortFiles()
  }, [files, searchQuery, sortBy, sortOrder, filterType])

  const loadFiles = async () => {
    try {
      const userFiles = await getFiles()
      setFiles(userFiles)
    } catch (error) {
      console.error("Error loading files:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const filterAndSortFiles = () => {
    let filtered = [...files]

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter((file) => file.name.toLowerCase().includes(searchQuery.toLowerCase()))
    }

    // Filter by type
    if (filterType !== "all") {
      filtered = filtered.filter((file) => {
        switch (filterType) {
          case "images":
            return file.type.startsWith("image/")
          case "videos":
            return file.type.startsWith("video/")
          case "documents":
            return file.type.includes("pdf") || file.type.includes("doc") || file.type.includes("txt")
          case "audio":
            return file.type.startsWith("audio/")
          case "favorites":
            return file.isFavorite
          default:
            return true
        }
      })
    }

    // Sort files
    filtered.sort((a, b) => {
      let comparison = 0
      switch (sortBy) {
        case "name":
          comparison = a.name.localeCompare(b.name)
          break
        case "size":
          comparison = a.size - b.size
          break
        case "date":
          comparison = new Date(a.uploadedAt).getTime() - new Date(b.uploadedAt).getTime()
          break
        default:
          comparison = 0
      }
      return sortOrder === "asc" ? comparison : -comparison
    })

    setFilteredFiles(filtered)
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400"></div>
      </div>
    )
  }

  return (
    <DashboardLayout user={user} currentPath="Dashboard > Files" onFileUpload={loadFiles}>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              Semua File
            </h1>
            <p className="text-slate-400 mt-1">Kelola dan organize semua file Anda ({filteredFiles.length} file)</p>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="flex flex-col lg:flex-row gap-4 p-4 bg-slate-800/30 rounded-xl border border-slate-700/30 backdrop-blur-sm">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
            <Input
              placeholder="Cari file..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-purple-500 focus:ring-purple-500/20"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-40 bg-slate-700/50 border-slate-600 text-white">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                <SelectItem value="all">Semua File</SelectItem>
                <SelectItem value="images">Gambar</SelectItem>
                <SelectItem value="videos">Video</SelectItem>
                <SelectItem value="documents">Dokumen</SelectItem>
                <SelectItem value="audio">Audio</SelectItem>
                <SelectItem value="favorites">Favorit</SelectItem>
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-32 bg-slate-700/50 border-slate-600 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                <SelectItem value="date">Tanggal</SelectItem>
                <SelectItem value="name">Nama</SelectItem>
                <SelectItem value="size">Ukuran</SelectItem>
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              size="sm"
              onClick={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")}
              className="border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              {sortOrder === "asc" ? <SortAsc className="h-4 w-4" /> : <SortDesc className="h-4 w-4" />}
            </Button>

            <div className="flex border border-slate-600 rounded-lg overflow-hidden">
              <Button
                variant={viewMode === "grid" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("grid")}
                className={`rounded-none ${
                  viewMode === "grid" ? "bg-purple-600 text-white" : "text-slate-300 hover:bg-slate-700"
                }`}
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === "list" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("list")}
                className={`rounded-none ${
                  viewMode === "list" ? "bg-purple-600 text-white" : "text-slate-300 hover:bg-slate-700"
                }`}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Files Display */}
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400"></div>
          </div>
        ) : (
          <FileGrid files={filteredFiles} onFileChange={loadFiles} viewMode={viewMode} />
        )}
      </div>
    </DashboardLayout>
  )
}

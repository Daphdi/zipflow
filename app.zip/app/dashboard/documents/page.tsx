"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { checkAuth } from "@/lib/auth"
import DashboardLayout from "@/components/dashboard-layout"
import FileGrid from "@/components/file-grid"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { getFiles } from "@/lib/files"
import {
  Search,
  Filter,
  Grid,
  List,
  SortAsc,
  SortDesc,
  FileText,
  Calendar,
  FileSpreadsheet,
  FileImage,
  Presentation,
} from "lucide-react"
import type { FileItem } from "@/lib/types"

export default function DocumentsPage() {
  const [user, setUser] = useState<any>(null)
  const [files, setFiles] = useState<FileItem[]>([])
  const [filteredFiles, setFilteredFiles] = useState<FileItem[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [sortBy, setSortBy] = useState("date")
  const [sortOrder, setSortOrder] = useState("desc")
  const [filterType, setFilterType] = useState("all")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const router = useRouter()

  useEffect(() => {
    const currentUser = checkAuth()
    if (!currentUser) {
      router.push("/")
      return
    }

    setUser(currentUser)
    loadFiles()
  }, [router])

  useEffect(() => {
    filterAndSortFiles()
  }, [files, searchQuery, sortBy, sortOrder, filterType])

  const loadFiles = async () => {
    try {
      const userFiles = await getFiles()
      // Filter hanya dokumen dengan kategori yang lebih spesifik
      const documents = userFiles.filter(
        (file) =>
          file.type.includes("pdf") ||
          file.type.includes("doc") ||
          file.type.includes("txt") ||
          file.type.includes("sheet") ||
          file.type.includes("presentation") ||
          file.type.includes("rtf") ||
          file.type.includes("odt") ||
          file.type.includes("csv") ||
          file.type.includes("xls") ||
          file.type.includes("ppt"),
      )
      setFiles(documents)
    } catch (error) {
      console.error("Error loading files:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const filterAndSortFiles = () => {
    let filtered = [...files]

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter((file) => file.name.toLowerCase().includes(searchQuery.toLowerCase()))
    }

    // Filter by document type
    if (filterType !== "all") {
      filtered = filtered.filter((file) => {
        switch (filterType) {
          case "pdf":
            return file.type.includes("pdf")
          case "word":
            return file.type.includes("doc") || file.type.includes("odt")
          case "excel":
            return file.type.includes("sheet") || file.type.includes("xls") || file.type.includes("csv")
          case "powerpoint":
            return file.type.includes("presentation") || file.type.includes("ppt")
          case "text":
            return file.type.includes("txt") || file.type.includes("rtf")
          default:
            return true
        }
      })
    }

    // Sort files
    filtered.sort((a, b) => {
      let comparison = 0
      switch (sortBy) {
        case "name":
          comparison = a.name.localeCompare(b.name)
          break
        case "size":
          comparison = a.size - b.size
          break
        case "date":
          comparison = new Date(a.uploadedAt).getTime() - new Date(b.uploadedAt).getTime()
          break
        default:
          comparison = 0
      }
      return sortOrder === "asc" ? comparison : -comparison
    })

    setFilteredFiles(filtered)
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i]
  }

  const getDocumentStats = () => {
    const stats = {
      pdf: files.filter((f) => f.type.includes("pdf")).length,
      word: files.filter((f) => f.type.includes("doc") || f.type.includes("odt")).length,
      excel: files.filter((f) => f.type.includes("sheet") || f.type.includes("xls") || f.type.includes("csv")).length,
      powerpoint: files.filter((f) => f.type.includes("presentation") || f.type.includes("ppt")).length,
      text: files.filter((f) => f.type.includes("txt") || f.type.includes("rtf")).length,
    }
    return stats
  }

  const getTotalSize = () => {
    return files.reduce((total, file) => total + file.size, 0)
  }

  const getRecentDocuments = () => {
    return files.sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()).slice(0, 3)
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400"></div>
      </div>
    )
  }

  const documentStats = getDocumentStats()
  const totalSize = getTotalSize()
  const recentDocs = getRecentDocuments()

  return (
    <DashboardLayout user={user} currentPath="Dashboard > Documents" onFileUpload={loadFiles}>
      <div className="space-y-8">
        {/* Enhanced Header with Stats */}
        <div className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-emerald-600/20 to-blue-600/20 rounded-3xl"></div>
          <div className="relative p-8 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-500/20 rounded-full text-emerald-300 text-sm font-medium mb-6">
              <FileText className="h-4 w-4" />
              Document Center
            </div>
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-emerald-400 via-blue-400 to-emerald-400 bg-clip-text text-transparent mb-4">
              Dokumen Anda
            </h1>
            <p className="text-slate-400 text-lg max-w-2xl mx-auto leading-relaxed">
              Kelola semua dokumen penting Anda dalam satu tempat. PDF, Word, Excel, PowerPoint, dan lainnya.
            </p>
            <div className="flex flex-wrap justify-center gap-6 mt-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-white">{files.length}</div>
                <div className="text-sm text-slate-400">Total Dokumen</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-emerald-400">{formatFileSize(totalSize)}</div>
                <div className="text-sm text-slate-400">Total Ukuran</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-400">{Object.keys(documentStats).length}</div>
                <div className="text-sm text-slate-400">Jenis Format</div>
              </div>
            </div>
          </div>
        </div>

        {/* Document Type Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card className="bg-gradient-to-br from-red-500/10 to-red-600/5 border-red-400/20 hover:border-red-400/40 transition-all duration-300">
            <CardContent className="p-4 text-center">
              <div className="p-3 bg-red-500/20 rounded-xl w-fit mx-auto mb-3">
                <FileText className="h-6 w-6 text-red-400" />
              </div>
              <div className="text-2xl font-bold text-white mb-1">{documentStats.pdf}</div>
              <div className="text-sm text-slate-400">PDF Files</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/5 border-blue-400/20 hover:border-blue-400/40 transition-all duration-300">
            <CardContent className="p-4 text-center">
              <div className="p-3 bg-blue-500/20 rounded-xl w-fit mx-auto mb-3">
                <FileImage className="h-6 w-6 text-blue-400" />
              </div>
              <div className="text-2xl font-bold text-white mb-1">{documentStats.word}</div>
              <div className="text-sm text-slate-400">Word Docs</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500/10 to-green-600/5 border-green-400/20 hover:border-green-400/40 transition-all duration-300">
            <CardContent className="p-4 text-center">
              <div className="p-3 bg-green-500/20 rounded-xl w-fit mx-auto mb-3">
                <FileSpreadsheet className="h-6 w-6 text-green-400" />
              </div>
              <div className="text-2xl font-bold text-white mb-1">{documentStats.excel}</div>
              <div className="text-sm text-slate-400">Spreadsheets</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-500/10 to-orange-600/5 border-orange-400/20 hover:border-orange-400/40 transition-all duration-300">
            <CardContent className="p-4 text-center">
              <div className="p-3 bg-orange-500/20 rounded-xl w-fit mx-auto mb-3">
                <Presentation className="h-6 w-6 text-orange-400" />
              </div>
              <div className="text-2xl font-bold text-white mb-1">{documentStats.powerpoint}</div>
              <div className="text-sm text-slate-400">Presentations</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/5 border-purple-400/20 hover:border-purple-400/40 transition-all duration-300">
            <CardContent className="p-4 text-center">
              <div className="p-3 bg-purple-500/20 rounded-xl w-fit mx-auto mb-3">
                <FileText className="h-6 w-6 text-purple-400" />
              </div>
              <div className="text-2xl font-bold text-white mb-1">{documentStats.text}</div>
              <div className="text-sm text-slate-400">Text Files</div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Documents Preview */}
        {recentDocs.length > 0 && (
          <Card className="bg-gradient-to-br from-slate-800/80 to-slate-900/90 border-slate-600/50">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-3">
                <div className="p-2 bg-emerald-500/20 rounded-lg">
                  <Calendar className="h-5 w-5 text-emerald-400" />
                </div>
                Dokumen Terbaru
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {recentDocs.map((doc) => (
                  <div
                    key={doc.id}
                    className="p-4 bg-slate-800/50 rounded-xl border border-slate-700/30 hover:border-emerald-400/30 transition-all duration-300"
                  >
                    <div className="flex items-start gap-3">
                      <div className="p-2 bg-emerald-500/20 rounded-lg">
                        <FileText className="h-5 w-5 text-emerald-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-white truncate">{doc.name}</h4>
                        <div className="flex items-center gap-2 mt-1 text-sm text-slate-400">
                          <span>{formatFileSize(doc.size)}</span>
                          <span>•</span>
                          <span>{new Date(doc.uploadedAt).toLocaleDateString("id-ID")}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Enhanced Filters and Search */}
        <div className="flex flex-col lg:flex-row gap-4 p-6 bg-slate-800/30 rounded-2xl border border-slate-700/30 backdrop-blur-sm">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
            <Input
              placeholder="Cari dokumen..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-emerald-500 focus:ring-emerald-500/20"
            />
          </div>

          <div className="flex flex-wrap gap-3">
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-48 bg-slate-700/50 border-slate-600 text-white">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                <SelectItem value="all">Semua Dokumen</SelectItem>
                <SelectItem value="pdf">PDF Files</SelectItem>
                <SelectItem value="word">Word Documents</SelectItem>
                <SelectItem value="excel">Spreadsheets</SelectItem>
                <SelectItem value="powerpoint">Presentations</SelectItem>
                <SelectItem value="text">Text Files</SelectItem>
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-32 bg-slate-700/50 border-slate-600 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                <SelectItem value="date">Tanggal</SelectItem>
                <SelectItem value="name">Nama</SelectItem>
                <SelectItem value="size">Ukuran</SelectItem>
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              size="sm"
              onClick={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")}
              className="border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              {sortOrder === "asc" ? <SortAsc className="h-4 w-4" /> : <SortDesc className="h-4 w-4" />}
            </Button>

            <div className="flex border border-slate-600 rounded-lg overflow-hidden">
              <Button
                variant={viewMode === "grid" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("grid")}
                className={`rounded-none ${
                  viewMode === "grid" ? "bg-emerald-600 text-white" : "text-slate-300 hover:bg-slate-700"
                }`}
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === "list" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("list")}
                className={`rounded-none ${
                  viewMode === "list" ? "bg-emerald-600 text-white" : "text-slate-300 hover:bg-slate-700"
                }`}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Documents Display */}
        {isLoading ? (
          <div className="flex items-center justify-center py-16">
            <div className="relative">
              <div className="animate-spin rounded-full h-12 w-12 border-4 border-emerald-500/20 border-t-emerald-500"></div>
              <div className="absolute inset-0 animate-ping rounded-full h-12 w-12 border-4 border-emerald-500/10"></div>
            </div>
          </div>
        ) : filteredFiles.length === 0 ? (
          <div className="text-center py-16">
            <div className="p-6 bg-slate-800/50 rounded-3xl w-24 h-24 mx-auto mb-6 flex items-center justify-center">
              <FileText className="h-12 w-12 text-slate-500" />
            </div>
            <h3 className="text-xl font-semibold text-slate-300 mb-2">
              {searchQuery || filterType !== "all" ? "Tidak Ada Dokumen Ditemukan" : "Belum Ada Dokumen"}
            </h3>
            <p className="text-slate-500 max-w-md mx-auto">
              {searchQuery || filterType !== "all"
                ? "Coba ubah filter atau kata kunci pencarian"
                : "Upload dokumen pertama Anda untuk memulai"}
            </p>
          </div>
        ) : (
          <FileGrid files={filteredFiles} onFileChange={loadFiles} viewMode={viewMode} />
        )}
      </div>
    </DashboardLayout>
  )
}

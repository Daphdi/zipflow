"use client"

import { useState, useCallback } from "react"
import { useDropzone } from "react-dropzone"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Upload, X, File } from "lucide-react"
import { uploadFile } from "@/lib/files"
import { showToast } from "@/lib/toast"

interface UploadDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onUploadSuccess: () => void
}

export default function UploadDialog({ open, onOpenChange, onUploadSuccess }: UploadDialogProps) {
  const [files, setFiles] = useState<File[]>([])
  const [uploading, setUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setFiles((prev) => [...prev, ...acceptedFiles])
  }, [])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    multiple: true,
  })

  const removeFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index))
  }

  const handleUpload = async () => {
    if (files.length === 0) return

    setUploading(true)
    setUploadProgress(0)

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i]
        await uploadFile(file)
        setUploadProgress(((i + 1) / files.length) * 100)
      }

      showToast(`Berhasil mengupload ${files.length} file!`, "success")
      setFiles([])
      onUploadSuccess()
    } catch (error) {
      showToast("Gagal mengupload file", "error")
    } finally {
      setUploading(false)
      setUploadProgress(0)
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-gradient-to-br from-slate-800/95 to-slate-900/95 border border-sky-500/30 backdrop-blur-xl">
        <DialogHeader>
          <DialogTitle className="text-white">Upload File</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Drop Zone */}
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
              isDragActive ? "border-sky-500 bg-sky-50/5" : "border-slate-600 hover:border-slate-500"
            }`}
          >
            <input {...getInputProps()} />
            <Upload className="mx-auto h-12 w-12 text-slate-400 mb-4" />
            {isDragActive ? (
              <p className="text-sky-400">Lepaskan file di sini...</p>
            ) : (
              <div>
                <p className="text-slate-300 mb-2">Drag & drop file di sini, atau klik untuk memilih</p>
                <p className="text-sm text-slate-400">Mendukung semua jenis file</p>
              </div>
            )}
          </div>

          {/* File List */}
          {files.length > 0 && (
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {files.map((file, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-2 bg-slate-800/50 rounded border border-slate-700/30"
                >
                  <div className="flex items-center space-x-2">
                    <File className="h-4 w-4 text-slate-400" />
                    <div>
                      <p className="text-sm font-medium truncate max-w-[200px] text-white">{file.name}</p>
                      <p className="text-xs text-slate-400">{formatFileSize(file.size)}</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => removeFile(index)} disabled={uploading}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}

          {/* Upload Progress */}
          {uploading && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-300">Mengupload...</span>
                <span className="text-slate-300">{Math.round(uploadProgress)}%</span>
              </div>
              <Progress value={uploadProgress} className="w-full bg-slate-700">
                <div
                  className="h-full bg-gradient-to-r from-sky-500 to-blue-500 rounded-full transition-all"
                  style={{ width: `${uploadProgress}%` }}
                />
              </Progress>
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-end space-x-2">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={uploading}
              className="border-slate-600 text-slate-300"
            >
              Batal
            </Button>
            <Button
              onClick={handleUpload}
              disabled={files.length === 0 || uploading}
              className="bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-700 hover:to-blue-700 text-white"
            >
              {uploading ? "Mengupload..." : `Upload ${files.length} File`}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
